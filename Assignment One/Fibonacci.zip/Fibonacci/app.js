const fibonnaci = require ("./calcFibonacci");
var fib1 = 30;
var fib2 = -10;
console.log("Fibonacci of 30 is : "+ fibonnaci(30));
console.log("Fibonacci of -15 is : "+ fibonnaci(-15));